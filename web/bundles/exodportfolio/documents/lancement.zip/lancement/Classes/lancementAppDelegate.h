//
//  lancementAppDelegate.h
//  lancement
//
//  Created by etudiant on 11/01/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@class lancementViewController;

@interface lancementAppDelegate : NSObject <UIApplicationDelegate> {
    UIWindow *window;
    lancementViewController *viewController;
}

@property (nonatomic, retain) IBOutlet UIWindow *window;
@property (nonatomic, retain) IBOutlet lancementViewController *viewController;

@end

