//
//  lancementViewController.m
//  lancement
//
//  Created by etudiant on 11/01/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "lancementViewController.h"

@implementation lancementViewController

@synthesize NouveauJeu;
@synthesize Regle;
UIImageView *acceuil;
UILabel *monLabel;
UIImageView *vueImage;
UIImageView *viewShip;

//gestion score
UILabel *labelScore;
int score;

//asteroidefile
UIImageView *viewAstero1;
UIImageView *viewAstero2;
UIImageView *viewAstero3;

//projectiles
UIImageView *balle1;
UIImageView *balle2;
UIImageView *balle3;
//controle des tirs
BOOL controleTir;
//controle des collisions
BOOL controleColli;
//timer
NSTimer *timer;

//gestion de l'accelerometre
UIAccelerometer *accel;

//gestion du son
NSURL *url; 
NSError *error;
AVAudioPlayer *audioPlayer; 

//gestion video
MPMoviePlayerViewController *movie;


/*
// The designated initializer. Override to perform setup that is required before the view is loaded.
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    if ((self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil])) {
        // Custom initialization
    }
    return self;
}
*/

/*
// Implement loadView to create a view hierarchy programmatically, without using a nib.
- (void)loadView {
}
*/



// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad {
    [super viewDidLoad];
	UIImage *imageAcceuil=[UIImage imageNamed:@"acceuil.png"];
	acceuil=[[UIImageView alloc] initWithImage:imageAcceuil];
	acceuil.frame=CGRectMake(0,0,acceuil.frame.size.width,acceuil.frame.size.height);	
	[self.view addSubview:acceuil];
	
}



/*
// Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}
*/

- (void)didReceiveMemoryWarning {
	// Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
	
	// Release any cached data, images, etc that aren't in use.
}

- (void)viewDidUnload {
	// Release any retained subviews of the main view.
	// e.g. self.myOutlet = nil;
}


- (void)dealloc {
    [super dealloc];
}

-(void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{
	if(vueImage!=nil)
	{
		[vueImage removeFromSuperview];
		[monLabel removeFromSuperview];
		
		vueImage=nil;
	}
	
	if(viewShip!=nil && controleTir)
	{
		//on active le son
		//[audioPlayer play];
		
		//suivant la position du vaisseau on gere l'angle des images et la position de départ
		if(viewShip.frame.origin.y<=35)
		{
			//position 1
			balle1.frame=CGRectMake(viewShip.frame.origin.x,viewShip.frame.origin.y,balle1.frame.size.width,balle1.frame.size.height);
			balle2.frame=CGRectMake(viewShip.frame.origin.x+25,viewShip.frame.origin.y,balle2.frame.size.width,balle2.frame.size.height);
			balle3.frame=CGRectMake(viewShip.frame.origin.x+50,viewShip.frame.origin.y,balle3.frame.size.width,balle3.frame.size.height);
			
			//rotation
			balle1.center=CGPointMake(balle1.frame.origin.x+ balle1.frame.size.width/2,balle1.frame.origin.y+balle1.frame.size.height/2);
			balle1.transform= CGAffineTransformMakeRotation(M_PI);
			
			balle2.center=CGPointMake(balle2.frame.origin.x+ balle2.frame.size.width/2,balle2.frame.origin.y+balle2.frame.size.height/2);
			balle2.transform= CGAffineTransformMakeRotation(M_PI);
			
			balle3.center=CGPointMake(balle3.frame.origin.x+ balle3.frame.size.width/2,balle3.frame.origin.y+balle3.frame.size.height/2);
			balle3.transform= CGAffineTransformMakeRotation(M_PI);
		}
		else if(viewShip.frame.origin.y>=435)
		{
			balle1.frame=CGRectMake(viewShip.frame.origin.x,viewShip.frame.origin.y,balle1.frame.size.width,balle1.frame.size.height);
			balle2.frame=CGRectMake(viewShip.frame.origin.x+25,viewShip.frame.origin.y,balle2.frame.size.width,balle2.frame.size.height);
			balle3.frame=CGRectMake(viewShip.frame.origin.x+50,viewShip.frame.origin.y,balle3.frame.size.width,balle3.frame.size.height);
		}
		else
		{
			if(viewShip.frame.origin.x<=10)
			{
				//position 1
				balle1.frame=CGRectMake(viewShip.frame.origin.x,viewShip.frame.origin.y,balle1.frame.size.width,balle1.frame.size.height);
				balle2.frame=CGRectMake(viewShip.frame.origin.x,viewShip.frame.origin.y+25,balle2.frame.size.width,balle2.frame.size.height);
				balle3.frame=CGRectMake(viewShip.frame.origin.x,viewShip.frame.origin.y+50,balle3.frame.size.width,balle3.frame.size.height);
				
				//rotation
				balle1.center=CGPointMake(balle1.frame.origin.x+ balle1.frame.size.width/2,balle1.frame.origin.y+balle1.frame.size.height/2);
				balle1.transform= CGAffineTransformMakeRotation(M_PI/2);
				
				balle2.center=CGPointMake(balle2.frame.origin.x+ balle2.frame.size.width/2,balle2.frame.origin.y+balle2.frame.size.height/2);
				balle2.transform= CGAffineTransformMakeRotation(M_PI/2);
				
				balle3.center=CGPointMake(balle3.frame.origin.x+ balle3.frame.size.width/2,balle3.frame.origin.y+balle3.frame.size.height/2);
				balle3.transform= CGAffineTransformMakeRotation(M_PI/2);
			}
			else if(viewShip.frame.origin.x>=285)
			{
				//position 1
				balle1.frame=CGRectMake(viewShip.frame.origin.x,viewShip.frame.origin.y,balle1.frame.size.width,balle1.frame.size.height);
				balle2.frame=CGRectMake(viewShip.frame.origin.x,viewShip.frame.origin.y+25,balle2.frame.size.width,balle2.frame.size.height);
				balle3.frame=CGRectMake(viewShip.frame.origin.x,viewShip.frame.origin.y+50,balle3.frame.size.width,balle3.frame.size.height);
				
				//rotation
				balle1.center=CGPointMake(balle1.frame.origin.x+ balle1.frame.size.width/2,balle1.frame.origin.y+balle1.frame.size.height/2);
				balle1.transform= CGAffineTransformMakeRotation(-M_PI/2);
				
				balle2.center=CGPointMake(balle2.frame.origin.x+ balle2.frame.size.width/2,balle2.frame.origin.y+balle2.frame.size.height/2);
				balle2.transform= CGAffineTransformMakeRotation(-M_PI/2);
				
				balle3.center=CGPointMake(balle3.frame.origin.x+ balle3.frame.size.width/2,balle3.frame.origin.y+balle3.frame.size.height/2);
				balle3.transform= CGAffineTransformMakeRotation(-M_PI/2);
			}
		}
		
		//on ajoute les balle
		[self.view addSubview:balle1];
		[self.view addSubview:balle2];
		[self.view addSubview:balle3];
		//on bloque les tirs
		controleTir=false;
		//on ajoute le timer pour les faire se deplacer
		
		if(timer==nil)
		{
			timer=[NSTimer scheduledTimerWithTimeInterval:0.005f target:self selector:@selector(deplacementBalle) userInfo:nil repeats:YES];
		}
	}
}

-(void)deplacementBalle
{
	//le deplacement de la balle
	if(viewShip.frame.origin.y<=35)
	{
		balle1.frame=CGRectMake(balle1.frame.origin.x,balle1.frame.origin.y+5,balle1.frame.size.width,balle1.frame.size.height);
		balle2.frame=CGRectMake(balle2.frame.origin.x,balle2.frame.origin.y+5,balle2.frame.size.width,balle2.frame.size.height);
		balle3.frame=CGRectMake(balle3.frame.origin.x,balle3.frame.origin.y+5,balle3.frame.size.width,balle3.frame.size.height);
	}
	else if(viewShip.frame.origin.y>35 && viewShip.frame.origin.y<435)
	{
		if(viewShip.frame.origin.x<=10)
		{
			balle1.frame=CGRectMake(balle1.frame.origin.x+5,balle1.frame.origin.y,balle1.frame.size.width,balle1.frame.size.height);
			balle2.frame=CGRectMake(balle2.frame.origin.x+5,balle2.frame.origin.y,balle2.frame.size.width,balle2.frame.size.height);
			balle3.frame=CGRectMake(balle3.frame.origin.x+5,balle3.frame.origin.y,balle3.frame.size.width,balle3.frame.size.height);
		}
		else if(viewShip.frame.origin.x>=285)
		{
			balle1.frame=CGRectMake(balle1.frame.origin.x-5,balle1.frame.origin.y,balle1.frame.size.width,balle1.frame.size.height);
			balle2.frame=CGRectMake(balle2.frame.origin.x-5,balle2.frame.origin.y,balle2.frame.size.width,balle2.frame.size.height);
			balle3.frame=CGRectMake(balle3.frame.origin.x-5,balle3.frame.origin.y,balle3.frame.size.width,balle3.frame.size.height);
		}
	}
	else if(viewShip.frame.origin.y>=435)
	{
		balle1.frame=CGRectMake(balle1.frame.origin.x,balle1.frame.origin.y-5,balle1.frame.size.width,balle1.frame.size.height);
		balle2.frame=CGRectMake(balle2.frame.origin.x,balle2.frame.origin.y-5,balle2.frame.size.width,balle2.frame.size.height);
		balle3.frame=CGRectMake(balle3.frame.origin.x,balle3.frame.origin.y-5,balle3.frame.size.width,balle3.frame.size.height);
	}


	if(balle1.frame.origin.y<-20 || balle1.frame.origin.y>480)
	{
		[timer invalidate];
		timer=nil;
		controleTir=true;
		controleColli=true;
	}
	else
	{
		if(balle1.frame.origin.x<-20 || balle1.frame.origin.x>350)
		{
			[timer invalidate];
			timer=nil;
			controleTir=true;
			controleColli=true;
		}
	}
	
	//le test collision est trop rapide on doit utiliser un boolean pour le canaliser
	//test collision, a faire pour toutes les balles
	if(CGRectIntersectsRect(balle1.frame, viewAstero1.frame) && controleColli)
	{
		if(CGRectIntersectsRect(balle2.frame, viewAstero2.frame))
		{
			if(CGRectIntersectsRect(balle3.frame, viewAstero3.frame))
			{
				score++;
				[self majLabel];
				controleColli=false;
				//on relance les asteroides
				[self relanceAstero];
			}
		}
	}
}
	   
-(void) majLabel
{
	labelScore.text=[NSString stringWithFormat:@"score: %d",score];
}

- (IBAction)actRegle:(id)sender {
	
	/*
	//ajout du label de regles
	monLabel=[[[UILabel alloc] initWithFrame:CGRectMake(0, 0, 320, 480)] autorelease];
	monLabel.text=@"Les regles du jeu explicité ici";
	[self.view addSubview:monLabel];
	
	//ajout de la fleche retour
	UIImage *monImage=[UIImage imageNamed:@"fleche_retour.png"];
	vueImage=[[UIImageView alloc] initWithImage:monImage];
	vueImage.frame=CGRectMake(280,400,30,30);	
	[self.view addSubview:vueImage];
	 */
/*	
	NSURLResponse *rep=[NSURLConnection sendSynchronousRequest:laRequette returningResponse: &rep error: &err];;
	NSError *err=nil;
	NSURLRequest *laRequette=[NSURLRequest requestWithURL:[NSURL URLWithString:lurl.text]];
	
	NSData *reponse = nil;
	NSString *lachaine = nil; 
	
	lachaine = [[NSString alloc] initWithData:reponse encoding:NSUTF8StringEncoding]; 
	[affiche setText:lachaine];
*/
 }
	   
-(void)astero
{
	//on charge les 3 asteroides que l'on positionne suivant une variable aleatoire
	UIImage *imageAstero1=[UIImage imageNamed:@"Asteroid.png"];
	viewAstero1=[[UIImageView alloc] initWithImage:imageAstero1];
	
	UIImage *imageAstero2=[UIImage imageNamed:@"Asteroid.png"];
	viewAstero2=[[UIImageView alloc] initWithImage:imageAstero2];
	
	UIImage *imageAstero3=[UIImage imageNamed:@"Asteroid.png"];
	viewAstero3=[[UIImageView alloc] initWithImage:imageAstero3];
	
	//on ajoute le timer
	[self relanceAstero];
}

-(void)relanceAstero
{	
	//composante aleatoire de 0 a 2-1
	if(arc4random() % 2 ==0)
	{
		//deuxieme composante aleatoire pour la position
		//en colone +30 par asteroide
		int randX=arc4random() % 240 + 40;
		int randY=arc4random() % 280 + 70;
		viewAstero1.frame=CGRectMake(randX,randY,25,30);	
		viewAstero2.frame=CGRectMake(randX,randY+30,25,30);
		viewAstero3.frame=CGRectMake(randX,randY+60,25,30);
	}
	else
	{
		//deuxieme composante aleatoire pour la position 
		//en ligne +25 par asteroide
		int randX=arc4random() % 180 + 40;
		int randY=arc4random() % 350 + 70;
		viewAstero1.frame=CGRectMake(randX,randY,25,30);	
		viewAstero2.frame=CGRectMake(randX+25,randY,25,30);
		viewAstero3.frame=CGRectMake(randX+50,randY,25,30);
	}
	
	
	//on add a la vue
	[self.view addSubview:viewAstero1];
	[self.view addSubview:viewAstero2];
	[self.view addSubview:viewAstero3];
}

-(void)bullet
{
	
	//on charge les projectiles
	UIImage *imageBalle1=[UIImage imageNamed:@"bullet.png"];
	balle1=[[UIImageView alloc] initWithImage:imageBalle1];
	
	UIImage *imageBalle2=[UIImage imageNamed:@"bullet.png"];
	balle2=[[UIImageView alloc] initWithImage:imageBalle2];
	
	UIImage *imageBalle3=[UIImage imageNamed:@"bullet.png"];
	balle3=[[UIImageView alloc] initWithImage:imageBalle3];
}


- (IBAction)actNouveauJeu:(id)sender 
{
	[self lancementFilm:@"intro" type:@"mp4"];
}

-(void)lancementJeu
{
	//on supprime les boutons
	[NouveauJeu removeFromSuperview];
	[NouveauJeu autorelease];
	[Regle removeFromSuperview];
	[Regle autorelease];
	
	
	//on initialise le score
	score=000;
	
	
	//on charge l'image de fond
	UIImage *imageFond=[UIImage imageNamed:@"fond.png"];
	UIImageView *viewFond=[[UIImageView alloc] initWithImage:imageFond];
	viewFond.frame=CGRectMake(0,0,viewFond.frame.size.width, viewFond.frame.size.height-20);	
	[self.view addSubview:viewFond];
	
	//on charge le label de score
	labelScore=[[[UILabel alloc] initWithFrame:CGRectMake(0, 0, 160, 25)] autorelease];
	labelScore.text=[NSString stringWithFormat:@"score: %d",score];
	labelScore.backgroundColor = [UIColor clearColor];
	labelScore.textColor = [UIColor whiteColor];
	[self.view addSubview:labelScore];
	
	
	//on charge l'image du vaisseau
	UIImage *imageShip=[UIImage imageNamed:@"ship.png"];
	viewShip=[[UIImageView alloc] initWithImage:imageShip];
	
	
	//------------------------------------------------------------------------position vaisseau
	viewShip.frame=CGRectMake(285,250,30, 15);	
	[self.view addSubview: viewShip];
	
	//on charge la premiere serie d'asteroide
	[self astero];
	
	//on charge les balles
	[self bullet];
	balle1.frame=CGRectMake(viewShip.frame.origin.x,viewShip.frame.origin.y,balle1.frame.size.width-5,balle1.frame.size.height-5);
	balle2.frame=CGRectMake(viewShip.frame.origin.x+25,viewShip.frame.origin.y,balle2.frame.size.width-5,balle2.frame.size.height-5);
	balle3.frame=CGRectMake(viewShip.frame.origin.x+50,viewShip.frame.origin.y,balle3.frame.size.width-5,balle3.frame.size.height-5);
	//on autorise le tir
	controleTir=true;
	//et les collision
	controleColli=true;
	
	//activation de l'accelerometre
	accel= [UIAccelerometer sharedAccelerometer];
	accel.delegate = self;
	accel.updateInterval = 1.0f/60.0f;
	
	//gestion du son
	url = [NSURL fileURLWithPath:[NSString stringWithFormat:@"%@/Cosmolazer.mp3", [[NSBundle mainBundle] resourcePath]]];
	audioPlayer = [[AVAudioPlayer alloc] initWithContentsOfURL:url error:&error];
	audioPlayer.numberOfLoops = 0;
}

-(void)accelerometer:(UIAccelerometer *) accel didAccelerate:(UIAcceleration *)aceler
{
	//deplacement x
	if(viewShip.frame.origin.y==35 || viewShip.frame.origin.y==435)
	{
		if(aceler.x>0.2f)
		{ 
			//vers la droite
			//on test et on le replace si necessaire		
			if(viewShip.frame.origin.x<=285)
			{
				viewShip.frame=CGRectMake(viewShip.frame.origin.x+(aceler.x*5),viewShip.frame.origin.y,30, 15);
			}
			else
			{
				viewShip.frame=CGRectMake(285,viewShip.frame.origin.y,30,15);
			}
			
		}
		else if(aceler.x<-0.2f)
		{
			//vers la gauche
			if(viewShip.frame.origin.x>=10)
			{
				viewShip.frame=CGRectMake(viewShip.frame.origin.x+(aceler.x*5),viewShip.frame.origin.y,30, 15);
			}
			else
			{
				viewShip.frame=CGRectMake(10,viewShip.frame.origin.y,30,15);
			}
			
		}
	}
	
	//deplacement y meme principe que pour le deplacment en Y
	if(viewShip.frame.origin.x==10 || viewShip.frame.origin.x==285)
	{
		if(aceler.y>0.2f)
		{
			if(viewShip.frame.origin.y>=35)
			{
				viewShip.frame=CGRectMake(viewShip.frame.origin.x,viewShip.frame.origin.y-(aceler.y*5),30, 15);
			}
			else
			{
				viewShip.frame=CGRectMake(viewShip.frame.origin.x,35,30,15);
			}
		}
		
		else if(aceler.y<-0.2f)
		{
			if(viewShip.frame.origin.y<=435)
			{
				viewShip.frame=CGRectMake(viewShip.frame.origin.x,viewShip.frame.origin.y-(aceler.y*5),30, 15);
			}
			else
			{
				viewShip.frame=CGRectMake(viewShip.frame.origin.x,435,30,15);
			}
			
		}
	}
	
}

//gestion film
-(void) lancementFilm: (NSString *) film type:(NSString *) leType {
	NSBundle *bundle=[NSBundle mainBundle];
	NSString *moviePath=[bundle pathForResource:film ofType:leType];
	movie=[[MPMoviePlayerViewController alloc] initWithContentURL:[NSURL fileURLWithPath:moviePath]];	
	
	[[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(finFilm:) name:MPMoviePlayerPlaybackDidFinishNotification object:nil];
	[self.view addSubview:movie.view];
    
    //---play movie---
    MPMoviePlayerController *player= [movie moviePlayer];
    [player play];
}

-(void) finFilm:(NSNotification *) maNotif
{	
	[[NSNotificationCenter defaultCenter] removeObserver:self name:MPMoviePlayerPlaybackDidFinishNotification object:nil];
	[movie.view removeFromSuperview];
	
	[movie autorelease];
	
	[self lancementJeu];
}

@end
