//
//  lancementViewController.h
//  lancement
//
//  Created by etudiant on 11/01/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <MediaPlayer/MediaPlayer.h>
#import <AVFoundation/AVFoundation.h>

@interface lancementViewController : UIViewController <UIAccelerometerDelegate>  {
	IBOutlet UIButton *NouveauJeu;
	IBOutlet UIButton *Regle;
	
}
- (IBAction)actNouveauJeu:(id)sender;
- (IBAction)actRegle:(id)sender;

@property(nonatomic,retain) IBOutlet UIButton *NouveauJeu;
@property(nonatomic,retain) IBOutlet UIButton *Regle;
@end

