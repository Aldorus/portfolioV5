
public class Enigme
{
	int id;
	String question, reponse, indice;
	
	Enigme(int id,String question,String indice,String reponse)
	{
		this.id=id;
		this.question=question;
		this.reponse=reponse;
		this.indice=indice;
	}
	
	//--- accesseur ---
	public int getId()
	{
		return id;
	}
	public String getReponse()
	{
		return reponse;
	}
	public String getIndice()
	{
		return indice;
	}
	public String getQuestion()
	{
		return question;
	}
	// --- methodes affichage ---
	public void afficher()
	{
		System.out.println(toString());
	}
	
	public String toString()
	{
		return id+": \n"+question+"\n"+reponse+"\n"+indice;
	}
	public boolean testReponse(String user)
	{
		int testeur=0;
		// alogorythme des reponses
		// on decoupe les chaine et on verifie que l'un des mots corespondent a un autre mot
		int pre=0;	
		String [] chaine=new String [30];
		
		for(int o=0; o<getReponse().length(); o++)
		{
			if(getReponse().charAt(o)==' ')
			{
				if(getReponse().substring(pre, o).equals(user))
				{	
					testeur++;
				}
				pre=o+1;
			}
			
		}
		
		if(testeur!=0)
		{
			return true;
		}
		else
		{
			return false;
		}
	}
	
	public String getBonneReponse()
	{
		String chaine="";
		for(int o=0; o<getReponse().length(); o++)
		{
			if(getReponse().charAt(o)==' ')
			{
				chaine+= getReponse().substring(0, o);
			}
		}
		return chaine;
	}
}


