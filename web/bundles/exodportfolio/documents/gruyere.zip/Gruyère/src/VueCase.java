import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.GraphicsConfiguration;
import java.awt.GraphicsEnvironment;
import java.awt.Image;
import java.awt.LayoutManager;
import java.awt.Toolkit;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;


public class VueCase extends JFrame {
	JLabel label1;
	JLabel label2;
	JLabel label3;
	JLabel label4;
	JLabel label5;
	JLabel label6;
	JLabel label7;
	JLabel label8;
	JLabel indice;
	JPanel p;
	
	// appel
	Monde m=new Monde();
	Controleur c=new Controleur(this,m);
	
	
	// constructeur
	public VueCase(){
		super("Gruy�re");
		
		creerFenetre();

	}
	
	public void creerFenetre(){
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setLayout(new BorderLayout());
		setSize(800,600);
		
		setJMenuBar(new JM(m,this));

		p=new JPanel();
		indice=new JLabel("indice: "+m.getIndice());
		
		add(p,BorderLayout.CENTER);
		add(indice,BorderLayout.SOUTH);
		
		afficherCase(1);
		
		
		this.getContentPane().setFocusable(true);
		this.getContentPane().requestFocus();
		this.getContentPane().addKeyListener(c);
		
		//setResizable(false);
		setVisible(true);
	}
	
	public void afficherCase(int vue){
		p.removeAll();
				
		switch(vue){
			case 1 :
				JLabel image1 = new JLabel();
				image1.setSize(800,590);
				image1.setIcon(new ImageIcon("Images/case1.jpg"));
				p.add(image1);
				break;
			case 2 :
				JLabel image2 = new JLabel();
				image2.setSize(800,590);
				image2.setIcon(new ImageIcon("Images/case2.jpg"));
				p.add(image2);
				break;
			case 3 :
				JLabel image3 = new JLabel();
				image3.setSize(800,590);
				image3.setIcon(new ImageIcon("Images/case3.jpg"));
				p.add(image3);
				break;
			case 4 :
				JLabel image4 = new JLabel();
				image4.setSize(800,590);
				image4.setIcon(new ImageIcon("Images/case4.jpg"));
				p.add(image4);
				break;
			case 5 :
				JLabel image5 = new JLabel();
				image5.setSize(800,590);
				image5.setIcon(new ImageIcon("Images/case5.jpg"));
				p.add(image5);
				break;
			case 6 :
				JLabel image6 = new JLabel();
				image6.setSize(800,590);
				image6.setIcon(new ImageIcon("Images/case6.jpg"));
				p.add(image6);
				break;
			case 7 :
				JLabel image7 = new JLabel();
				image7.setSize(800,590);
				image7.setIcon(new ImageIcon("Images/case7.jpg"));
				p.add(image7);
				break;
			case 8 :
				JLabel image8 = new JLabel();
				image8.setSize(800,590);
				image8.setIcon(new ImageIcon("Images/case8.jpg"));
				p.add(image8);
				break;
		
		}
		repaint();
	}
	public void majIndice(int i)
	{
		indice.setText("indice: "+i);
	}
	
	public void afficherEnigme(Enigme enigme)
	{
		// creation de la boite de dialogue pour repondre
		// une chaine de caractere + un textField
		Dialogue d=new Dialogue(enigme,this,m);
	}
	public void afficherIndice(String indice)
	{
		JOptionPane.showMessageDialog(null, indice);
	}
	
	public void afficherCombat()
	{
		JOptionPane.showMessageDialog(null, "Felicitation vous avez trouv� un indice");
	}
	
	public void win()
	{
		getContentPane().removeAll();
		getContentPane().add(new JLabel("FELICITATION, vous etez parvenu a ne pas vous suicider avant la fin. \n" +
				"Vous avez maintenant le droit de recommencer :p"));
	}
	
	// --- gestion sprite ---
	public void afficheFleche(int i) throws IOException 
	{
		System.out.println("affichage du sprite "+i);
		
	
		Sprite spr=new Sprite(new ImageIcon("Images/fleche1.gif"));
		add(spr);
		
	}
}

