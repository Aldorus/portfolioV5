import java.awt.BorderLayout;
import java.awt.Component;

import javax.swing.*;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

import com.sun.org.apache.bcel.internal.generic.SWAP;


public class Dialogue extends JFrame {
	JLabel label;
	
	// appel

	Monde m;
	VueCase v;
	JTextField reponse;
	
	// constructeur
	 Dialogue (Enigme enigme,VueCase v,Monde m){
		this.setTitle("Enigmes");
		this.setSize(750,500);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	
		this.m=m;
		this.getContentPane().setLayout(new GridLayout(3,1));
		
				reponse= new JTextField ();
				JTextArea temp=new JTextArea(enigme.question);
				temp.setEditable(true);
				JScrollPane question2= new JScrollPane (temp);
				
				JPanel boite=new JPanel();
				boite.setLayout(new GridLayout(1,3));
				//le premier bouton
				JButton bouton1= new JButton("Indice");
				
				//le deuxi�me bouton
				JButton bouton2= new JButton("Confirmer");
				
				//le troisi�me bouton
				
				JButton bouton3= new JButton("Passer");
			boite.add(bouton1);	
			boite.add(bouton2);	
			boite.add(bouton3);	
			this.getContentPane().add(question2);
			this.getContentPane().add(reponse);	
			this.getContentPane().add(boite);	
			
		
		
		this.setVisible(true); 
		
		//controleur
		bouton1.addActionListener(new ControleurDialogue(v,m,this,enigme));
		bouton2.addActionListener(new ControleurDialogue(v,m,this,enigme));
		bouton3.addActionListener(new ControleurDialogue(v,m,this,enigme));
		
	}


}
