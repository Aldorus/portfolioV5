import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.image.BufferedImage;

import javax.swing.ImageIcon;
import javax.swing.JPanel;

public class Sprite extends JPanel
{
	private ImageIcon image;
	private int x;
	private int y;
    BufferedImage bi;
    Graphics2D g2d;
	
	public Sprite(ImageIcon image)
	{
		this(image,50,50);
	}
	
	public Sprite(ImageIcon image,int x,int y)
	{
		set(x,y);
		this.image=image;
	}
	public void paintComponent(Graphics g)
	{
		super.paintComponent(g);         
        update(g);
	}
	public void update(Graphics g)
	{
		 Graphics2D g2 = (Graphics2D)g;

         int w=52;
         int h=53;
         bi = (BufferedImage)createImage(w,h);
         g2d=bi.createGraphics();
   	}
	public void dessinerFleche()
	{
		g2d.fillOval(0,0,200,200);
		//g2d.drawImage(this.image.getImage(), this.x,this.y,null);
	}
	public int getX()
	{
		return this.x;
	}
	public void setX(int x)
	{
		this.x=x;
	}
	public int getY()
	{
		return this.y;
	}
	public void setY(int y)
	{
		this.y=y;
	}
	public void set(int x,int y)
	{
		this.x=x;
		this.y=y;
	}
}
