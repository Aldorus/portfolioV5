
public class Monde
{
	int monde [][];
	int posX,posY,vue;
	static int indice;
	int aide;
	
	Monde()
	{
		monde=new int[22][18];
		initialisation();		
	}
	
	//--- m�thodes initialisation ---
	public void initialisation()
	{
		posX=16;
		posY=1;
		vue=2;
		indice=0;
		aide=0;
		for(int i=0;i<22;i++)
		{
			 for(int j=0;j<18;j++){	
				 //on cr� les mur autour du labyrinthes (des 4 cot�s)
				 			if(j==0){
				 				monde[i][j]=1;
				 					}
				 			if (j==17){
				 				monde[i][j]=1;	
				 					}
				 			if(i==0){
				 				monde[i][j]=1;
				 					}
				 			if(i==21){
				 				monde[i][j]=1;
				 					}
			 }
				 			
	    }
			 //ligne 1
			 monde[1][1]=1;
			 monde[1][17]=1;
			 monde[1][2]=1;
			 monde[1][15]=100;

			 //ligne 2
			 monde[2][2]=1;
			 monde[2][6]=1;
			 monde[2][7]=1;
			 monde[2][8]=1;
			 monde[2][10]=1;
			 monde[2][11]=1;
			 monde[2][12]=1;
			 monde[2][13]=1;
			 monde[2][15]=1;
			 monde[2][16]=1;
			 //liggne3
			 monde[3][2]=1;
			 monde[3][4]=1;
			 monde[3][5]=1;
			 monde[3][6]=1;
			 //ligne4
			 monde[4][2]=1;
			 monde[4][5]=1;
			 monde[4][6]=1;
			 monde[4][7]=1;
			 monde[4][8]=1;
			 monde[4][10]=1;
			 monde[4][11]=1;
			 monde[4][13]=1;
			 monde[4][14]=1;
			 monde[4][15]=1;
			 //ligne5
			 monde[5][2]=1;
			 monde[5][3]=1;
			 monde[5][5]=1;
			 monde[5][7]=1;
			 monde[5][8]=1;
			 monde[5][10]=1000;
			 monde[5][11]=1;
			 monde[5][13]=1;
			 monde[5][14]=100;
			 //ligne6
			 monde[6][3]=1;
			 monde[6][8]=1;
			 monde[6][9]=1;
			 monde[6][10]=1;
			 monde[6][11]=1;
			 monde[6][13]=1;
			 monde[6][14]=1;
			 monde[6][15]=1;
			 //ligne7
			 monde[7][1]=1;
			 monde[7][3]=1;
			 monde[7][4]=1;
			 monde[7][6]=1;
			 //ligne8
			 monde[8][1]=1;
			 monde[8][6]=1;
			 monde[8][8]=1;
			 monde[8][9]=1;
			 monde[8][10]=1;
			 monde[8][11]=1;
			 monde[8][12]=1000;
			 monde[8][13]=1;
			 monde[8][14]=1;
			 monde[8][15]=1;
			 monde[8][16]=1;
			 //ligne9
			 monde[9][1]=1;
			 monde[9][2]=1000;
			 monde[9][3]=1;
			 monde[9][5]=1;
			 monde[9][6]=1;
			 monde[9][8]=1;
			 //ligne10
			 monde[10][2]=100;
			 monde[10][8]=1;
			 monde[10][10]=1;
			 monde[10][11]=1;
			 monde[10][12]=1;
			 monde[10][13]=1;
			 monde[10][14]=200;
			 monde[10][15]=1;
			 monde[10][16]=1;
			 //ligne11
			 monde[11][1]=1;
			 monde[11][2]=1;
			 monde[11][3]=1;
			 monde[11][6]=1;
			 monde[11][11]=1;
			 //ligne12
			 monde[12][2]=1;
			 monde[12][3]=2000;
			 monde[12][4]=1;
			 monde[12][6]=1000;
			 monde[12][7]=1;
			 monde[12][8]=1;
			 monde[12][9]=1;
			 monde[12][10]=2000;
			 monde[12][11]=1;
			 monde[12][12]=1000;
			 monde[12][14]=1;
			 monde[12][15]=1;
			 monde[12][16]=1;
			 //ligne13
			 monde[13][2]=1;
			 monde[13][11]=1;
			 monde[13][14]=1;
			 //ligne14
			 monde[14][2]=1;
			 monde[14][4]=1;
			 monde[14][2]=1;
			 monde[14][4]=1;
			 monde[14][2]=1;
			 monde[14][6]=1;
			 monde[14][7]=1;
			 monde[14][8]=1;
			 monde[14][9]=1;
			 monde[14][11]=1;
			 monde[14][16]=1;
			 //ligne15
			 monde[15][2]=1;
			 monde[15][8]=1;
			 monde[15][11]=2000;
			 monde[15][14]=1;
			 //ligne16
			 monde[16][2]=1;
			 monde[16][3]=1;
			 monde[16][5]=1;
			 monde[16][6]=1;
			 monde[16][8]=1;
			 monde[16][9]=1;
			 monde[16][11]=1;
			 monde[16][12]=1;
			 monde[16][14]=1;
			 monde[16][15]=1; 
			 //ligne17
			 monde[17][8]=1;
			 monde[17][9]=1;
			 monde[17][11]=1;
			 monde[17][15]=200;
			 //ligne18
			 monde[18][1]=1;
			 monde[18][2]=1;
			 monde[18][3]=1;
			 monde[18][4]=1;
			 monde[18][5]=1;
			 monde[18][6]=1;
			 monde[18][7]=1;
			 monde[18][8]=1;
			 monde[18][9]=1;
			 monde[18][10]=1;
			 monde[18][11]=1;
			 monde[18][13]=1;
			 monde[18][14]=1;
			 monde[18][15]=1;
			 //ligne19
			 monde[19][1]=300;
			 monde[19][11]=1;
			 monde[19][13]=1;
			 monde[19][14]=1;
			 monde[19][15]=1;
			 //ligne20
			 monde[20][1]=10000;
			 monde[20][2]=1;
			 monde[20][3]=1;
			 monde[20][5]=1;
			 monde[20][6]=1;
			 monde[20][7]=1;
			 monde[20][8]=3000;
			 monde[20][9]=1;
			 monde[20][13]=1;
	}
	
	//--- M�thode d'affichage ---
	public String toString()
	{
		String chaine="";
		for(int i=0;i<22;i++)
		{
			for(int j=0;j<18;j++)
			{
				if(j==posX&&i==posY)
				{
					chaine+="x";
				}
				else
				{
					if(monde[i][j]>=100)
					{
						chaine+="e";
					}
					else
					{
						chaine+=monde[i][j];
					}
				}
			}
			chaine+="\n";
		}
		chaine+="Et le joueur regarde vers "+vue+"\n";
		return chaine;
	}
	
	public void afficher()
	{
		System.out.println(toString()+"\n"+vue);
	}
	
	public int getIndice()
	{
		return indice;
	}
	
	//--- m�thode test TERRAIN ---
	public int getCase()
	{
		return monde[posY][posX];
	}
	public boolean testSortie()
	{
		if(monde[posY][posX]==10000)
		{
			return true;
		}
		else
		{
			return false;
		}
	}
	public boolean testEnigme()
	{
		if(monde[posY][posX]>=100&&monde[posY][posX]<1000)
		{
			return true;
		}
		else
		{
			return false;
		}
	}
	public boolean testCombat()
	{
		if(monde[posY][posX]>=1000&&monde[posY][posX]<10000)
		{
			return true;
		}
		else
		{
			return false;
		}
	}
	public void combat()
	{
		indice++;
		suprCombat();
	}

	public void suprEnigme()
	{
		if(testEnigme())
		{
			//supression Enigme
			monde[posY][posX]=0;
		}
	}
	public void suprCombat()
	{
		if(testCombat())
		{
			//supression Combat
			monde[posY][posX]=0;
		}
	}
	
	//--- methode test deplacement --- d'un point de vue matricielle ---
	public boolean testHaut()
	{
		if(monde[posY-1][posX]!=1)
		{
			return true;
		}
		else
		{
			return false;
		}

	}
	public boolean testDroite()
	{
		if(monde[posY][posX+1]!=1)
		{
			return true;
		}
		else
		{
			return false;
		}
	}
	public boolean testGauche()
	{
		if(monde[posY][posX-1]!=1)
		{

			return true;
		}
		else
		{
			return false;
		}
	}
	public boolean testBas()
	{
		if(monde[posY+1][posX]!=1)
		{

			return true;
		}
		else
		{
			return false;
		}
	}
	
	//--- deplacement --- du point de vue de la vue
	public void haut()
	{
		if(vue==1)
		{
			if(testHaut())
			{
				posY--;
			}
		}
		if(vue==2)
		{
			if(testGauche())
			{
				posX--;
			}
		}
		if(vue==3)
		{
			if(testBas())
			{
				posY++;
			}
		}
		if(vue==4)
		{
			if(testDroite())
			{
				posX++;
			}
		}
		// pas de changement de la variable vue lorsqu'on va tout droit
	}
	
	public void droite()
	{
		if(vue==1)
		{
			if(testDroite())
			{
				posX++;
				vue=4;
			}
		}
		if(vue==2)
		{
			if(testHaut())
			{
				posY--;
				vue=1;
			}
		}
		if(vue==3)
		{
			if(testGauche())
			{
				posX--;
				vue=2;
			}
		}
		if(vue==4)
		{
			if(testBas())
			{
				posY++;
				vue=3;
			}
		}
	}
	public void gauche()
	{
		if(vue==1)
		{
			if(testGauche())
			{
				posX--;
				vue=2;
			}

		}
		if(vue==2)
		{
			if(testBas())
			{
				posY++;
				vue=3;
			}

		}
		if(vue==3)
		{
			if(testDroite())
			{
				posX++;
				vue=4;
			}
		}
		if(vue==4)
		{
			if(testHaut())
			{
				posY--;
				vue=1;
			}
		}
	}
	
	// se retourner
	public void retourner()
	{
		if(vue==1)
		{
			vue=3;
		}
		else if(vue==2)
		{
			vue=4;
		}
		else if(vue==3)
		{
			vue=1;
		}
		else if(vue==4)
		{
			vue=2;
		}
		
	}
	
	// --- gestion indice ---
	public void moinUnIndice()
	{
		indice--;
	}
	public void plusUnIndice()
	{
		indice++;
	}
	
	// --- gestion des vues ---
	public int choixCase()
	{
		// on fonction des posibilit� de deplacement il affiche une des 8 vue pssibles
		
		// si le joueur regarde vers le nord
		if(vue==1)
		{
			if(testHaut()&&testDroite()&&testGauche())
			{
				return 7;
			}
			else if(testDroite()&&testGauche()&&!testHaut())
			{
				return 8;
			}
			else if(testGauche()&&!testDroite()&&!testHaut())
			{
				return 6;
			}
			else if(testHaut()&&testGauche()&&!testDroite())
			{
				return 5;
			}
			else if(testDroite()&&!testHaut()&&!testGauche())
			{
				return 4;
			}
			else if(testHaut()&&testDroite()&&!testGauche())
			{
				return 3;
			}
			else if(testHaut()&&!testGauche()&&!testDroite())
			{
				return 1;
			}
			else
			{
				return 2;
			}
		}
		
		// si le joueur regarde vers l'ouest
		else if(vue==2)
		{

			if(testHaut()&&testBas()&&testGauche())
			{
				return 7;
			}
			else if(testHaut()&&testBas()&&!testGauche())
			{
				return 8;
			}
			else if(testBas()&&!testGauche()&&!testHaut())
			{
				return 6;
			}
			else if(testBas()&&testGauche()&&!testHaut())
			{
				return 5;
			}
			else if(testHaut()&&!testBas()&&!testGauche())
			{
				return 4;
			}
			else if(testHaut()&&testGauche()&&!testBas())
			{
				return 3;
			}
			else if(testGauche()&&!testBas()&&!testHaut())
			{
				return 1;
			}
			else
			{
				return 2;
			}
		}
		
		// si le joueur regarde vers le sud
		else if(vue==3)
		{
			if(testBas()&&testDroite()&&testGauche())
			{
				return 7;
			}
			else if(testDroite()&&testGauche()&&!testBas())
			{
				return 8;
			}
			else if(testDroite()&&!testGauche()&&!testBas())
			{
				return 6;
			}
			else if(testBas()&&testDroite()&&!testGauche())
			{
				return 5;
			}
			else if(testGauche()&&!testBas()&&!testDroite())// a reprendre
			{
				return 4;
			}
			else if(testBas()&&testGauche()&&!testDroite())
			{
				return 3;
			}
			else if(testBas()&&!testGauche()&&!testDroite())
			{
				return 1;
			}
			else
			{
				return 2;
			}
		}
		
		// si le joueur regarde vers l'est
		else if(vue==4)
		{
			if(testHaut()&&testBas()&&testDroite())
			{
				return 7;
			}
			else if(testHaut()&&testBas()&&!testDroite())
			{
				return 8;
			}
			else if(testHaut()&&!testDroite()&&!testBas())
			{
				return 6;
			}
			else if(testHaut()&&testDroite()&&!testBas())
			{
				return 5;
			}
			else if(testBas()&&!testHaut()&&!testDroite())
			{
				return 4;
			}
			else if(testBas()&&testDroite()&&!testHaut())
			{
				return 3;
			}
			else if(testDroite()&&!testHaut()&&!testBas())
			{
				return 1;
			}
			else
			{
				return 2;
			}
		}
		else 
		{
			return 2;
		}
	}
	
	// --- M�thodes matrice fl�che ---
	public int affichageFleche()
	{
		if(posY<=18 || (posY>18 && posX<4) )
		{
			//on descend
			if(vue==1)
			{
				return 3;
			}
			else if(vue==2)
			{
				return 2;
			}
			else if(vue==3)
			{
				return 1;
			}
			else if(vue==4)
			{
				return 4;
			}
			else
			{
				return 0;
			}
		}
		else if(posY>18 && posX>=4)
		{
			//on va a gauche
			if(vue==1)
			{
				return 2;
			}
			else if(vue==2)
			{
				return 1;
			}
			else if(vue==3)
			{
				return 4;
			}
			else if(vue==4)
			{
				return 3;
			}
			else
			{
				return 0;
			}
		}

		else
		{
			return 0;
		}		
	}
	public int getAide()
	{
		return aide;
	}
	public void majAide()
	{
		aide=4;
	}
}