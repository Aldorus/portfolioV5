
public class Testvuecase {
	public static void main( String []args) {
		VueCase ca=new VueCase();
	}
}
