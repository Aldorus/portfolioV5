import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;


public class ControleurDialogue implements ActionListener {
	VueCase vuecase;
	Monde monde;
	Dialogue dialogue;
	Enigme enigme;

	public ControleurDialogue(VueCase v,Monde m, Dialogue d, Enigme en){
		vuecase=v;
		monde=m;
		dialogue=d;
		enigme=en;		
	}
	
	public void actionPerformed (ActionEvent e){
		JButton b=(JButton)e.getSource();
		if(monde.getIndice()>0){
			if (b.getActionCommand().equals("Indice")){
				vuecase.afficherIndice(enigme.indice);
				monde.moinUnIndice();
				vuecase.majIndice(monde.getIndice());
			}
		}
		
		if (b.getActionCommand().equals("Passer")){
			dialogue.setVisible(false);
		}
		
		else if(b.getActionCommand().equals("Confirmer"))
		{
			if(enigme.testReponse(dialogue.reponse.getText().toLowerCase()))
			{
				monde.majAide();
				
				JOptionPane.showMessageDialog(null, "C'est la bonne reponse");
				
			}
			else
			{
				JOptionPane.showMessageDialog(null, "Mauvaise reponse, la bonne reponse �tait: "+enigme.getBonneReponse());
			}
			dialogue.setVisible(false);
		}
		monde.suprEnigme();
	}
}
