import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JOptionPane;


public class ControleurMenu implements ActionListener
{
	Monde m ;
	VueCase v;
	ControleurMenu(Monde m, VueCase v)
	{
		this.m=m;
		this.v=v;
	}

	public void actionPerformed(ActionEvent e)
	{
		String commande=e.getActionCommand();
		if(commande.equals("nouveau"))
		{
			m.initialisation();
			v.afficherCase(m.choixCase());
		}
		else if(commande.equals("quitter"))
		{
			System.exit(0);
		}
		else if(commande.equals("aide"))
		{
			JOptionPane.showMessageDialog(null, "Le but du jeu est de sortir du labyrinthe. \n" +
					"Pour cela vous pouvez �tre aid� par les enigmes � la condition que vous sachiez y repondre. \n " +
					"Bonne chance.");
		}
			
	}
}
