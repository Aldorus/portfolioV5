import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;


public class JM extends JMenuBar
{
	ControleurMenu blop;
	JM(Monde m, VueCase v)
	{
		blop=new ControleurMenu(m, v);
		JMenu jeu=new JMenu("Jeu");
			JMenuItem nouveau=new JMenuItem("Nouveau");
			nouveau.setActionCommand("nouveau");
			nouveau.addActionListener(blop);
			jeu.add(nouveau);
			
			JMenuItem quitter=new JMenuItem("Quitter");
			quitter.setActionCommand("quitter");
			quitter.addActionListener(blop);
			jeu.add(quitter);
		add(jeu);
		
		JMenu ap=new JMenu("a propos");
			JMenuItem aide=new JMenuItem("Aide");
			aide.setActionCommand("aide");
			aide.addActionListener(blop);
			ap.add(aide);
		add(aide);
	}
}
