import java.util.Vector;


public class StockEnigme
{
	// cette classe cree un vector d'enigme et permet d'en choisir une
	Vector <Enigme> v=new Vector<Enigme>();
	
	StockEnigme()
	{
		// on rentre les enigmes
		Enigme e1=new Enigme(101,"Un homme et son fils ont 36 ans � eux deux.\n" +
				"L�homme a 30 ans de plus que son fils.\n" +
				"Quel �ge a le fils?",	"Si le fils a 6 ans, quel age a le p�re?", "trois 3 "	);
		v.add(e1);
		Enigme e2=new Enigme(102,"Un homme et une femme tr�s amoureux sont dans un lit.\n " +
				"Sur la table de nuit � c�t� il y a une bougie.\n Qu'est-ce qui fond?", "R�fl�chir du point de" +
						" vue mat�riel", "bougie ");
		v.add(e2);
		Enigme e3=new Enigme(103,"Un gar�on et une fille sont n�s le m�me jour de la m�me ann�e et des m�mes parents.\n" +
				" Pourtant, ils ne sont pas jumeaux.\n Comment cela se peut-il ?","Ont-ils des fr�res et des soeurs","triple triplet 3 ");
		v.add(e3);
		Enigme e4=new Enigme(104,"Pourquoi est-il difficile d'�lever des escargots femelles?","Il n'existe ni d'escargots m�les ni femelles. " +
				 "R�fl�chir  � la sexualit� des escargots","hermaphrodites bi bi-sexuel ");
		v.add(e4);
		Enigme e5=new Enigme(105,"O� que je sois, on me l�che le dos et on me frappe au visage. Qui suis-je?",
				"Dos au sens figural bien sur", "timbre ");
		v.add(e5);
		Enigme e6=new Enigme(106,"Si on m'approche,\n je tue mais sans moi tu n'existerais pas. Qui suis-je?","Tu me vois 6 mois par an minimum"
				,"soleil ");
		v.add(e6);
		Enigme e7=new Enigme(107,"Un n�nuphar se trouve dans un lac. Tous les jours il double de taille. \n Au bout du 15 jours," +
				" il fait la moiti� du lac, au bout de combien de temps recouvra-t-il le lac enti�rement?",
				"Combien fait une moiti� foi deux?", "16 ");
		v.add(e7);
		Enigme e8=new Enigme(108,"Je vais tr�s vite et pourtant je n'ai ni jambes ni ailes.\nVous aurez beaucoup de mal � vous mesurer � moi," +
				"Mais si vous y arrivez, cela fera beaucoup de bruit.\nVous voulez me saisir ? Impossible. Me voir? Je suis invisible",
				"Ouvrez vos oreilles", "son ");
		v.add(e8);
		Enigme e9=new Enigme(109,"J'ai quatre dents mais je ne mord pas.\n Quand par hasard, j'attrape quelque chose, un goinfre me l'enleve aussitot","" +
				"Je suis convert d'aluminium","fourchette ");
		v.add(e9);
		Enigme e10=new Enigme(110,"Je fus demain, je serai hier","On peut encore me changer","aujourd'hui ");
		v.add(e10);
		Enigme e11=new Enigme(111,"Quand on en est loin, on y pense pas. \nPlus on s'en raproche plus on y pense. Quand elle est la on y pense plus","Ce n'est pas mat�riel","mort ");
		v.add(e11);	
		Enigme e12=new Enigme(202,"Vous �tes dans une chambre dont les quatre murs, le plancher et le plafond sont compl�tement recouverts de miroirs. � part vous-m�me, il n'y a rien d'autre dans la chambre.\n Combien de r�flexions de vous-m�me voyez-vous?",
				"Toute reflecion a besoin de ...??","aucune, 0 ");
		v.add(e12);
		Enigme e13=new Enigme(203,"En se rendant � un point d'eau dans la savane, un z�bre croisa six girafes.\n Chaque girafe transportait trois singes sur son dos.\n Chaque singe avait deux oiseaux sur la queue.\nCombien d'animaux se rendaient au point d'eau ?",
				"Dans quel sens se dirige les autres animaux","un 1 ");
		v.add(e13);
		Enigme e14=new Enigme(204,"Je contiens une seule lettre, je d�bute par e et je termine par e","Je suis materiel","enveloppe ");
		v.add(e14);
		Enigme e15=new Enigme(205,"Quand j'ai deux s on peut me manger.\n Quand on m'en retire un on ne le peut plus. Qui suis-je?","C'est bonpour la memoire","poisson poison");
		v.add(e15);
		Enigme e16=new Enigme(206,"Lorsqu'on l'ach�te, on ne s'en sert pas, et lorsqu'on s'en sert, on ne le sait pas","On ne peut plus non plus le voir, le sentir...","cercueil");
		v.add(e16);
		Enigme e17=new Enigme(207,"D�s que l'on me nomme je n'existe plus","Les professeurs le reclament souvent","silence");
		v.add(e17);
		Enigme e18=new Enigme(208,"Roland Spoutnik se prom�ne dans la for�t et arrive devant un fr�le pont de bois qui enjambe une rivi�re.\n Inquiet de savoir si le pont supportera son poids, il trouve un �criteau qui indique: poids autoris� 100 kg. \nRassur�, Roland Spoutnik qui ne p�se que 60 kg s'aventure sur le pont.\n Pourtant, le pont c�de. Pourquoi ? ",
				"repensez au proverbe","2 averti ");
		v.add(e18);
		Enigme e19=new Enigme(209,"Rom�o est un jeune homme tr�s romantique.\n Pourtant, il offre � sa petite amie Juliette, un objet creux, sans fond et destin� � contenir de la chair, des os et du sang.\n Quel peut �tre cet objet ? ","ils se sont fianc�s","bague ");
		v.add(e19);
		Enigme e20=new Enigme(201,"5.Parfois je suis fort. \nParfois je suis faible. \nJe parle toutes les langues, sans jamais les avoir apprises.","Les enfants repetent apr�s moi","echo ");
		v.add(e20);
		Enigme e21=new Enigme(301,"Un petit ver passe par l� et d�cide de les manger.\nIl traverse les livres de la premi�re page du premier volume � la derni�re page du dernier volume. \nCombien de pages a alors mang� (travers�es) le ver?","les extr�mit�s correspondent-t-elles � la premi�re page ou � la derni�re page des volumes 1 et 5","1502 ");
		v.add(e21);
		Enigme e22=new Enigme(302,"Le calife de Bagdad convoqua un jour tous les hommes mari�s de sa cit�.\nOn suppose que la monogamie �tait dans ces temps la r�gle. \nLe calife leur tint ces propos: \nAfin de lutter contre l'adult�re, je demande � chacun d'entre vous, s'il s'aper�oit qu'il est tromp�, de tuer sa femme le soir m�me � minuit.\nDe plus, je peux vous dire qu'au moins deux femmes sont infid�les � leur mari.\n�videmment, les habitants de Bagdad sont tr�s ob�issants � l'�gard de leur commandeur des croyants, et appliquent � la lettre tous les ordres donn�s. \nCependant, comme il est d'ailleurs toujours d'usage, les cocus sont les seuls � ignorer l'infid�lit� de leur femme.\n Chaque mari sait quelles sont les femmes infid�les des autres maris, mais ignore si sa propre femme l'est ou non.\n Par contre, on suppose que les habitants de Bagdad ont une grande intelligence logique, et qu'ils sont donc tout � fait capables de tirer des conclusions sur leur propre situation � partir du comportement des autres.\nRien ne se passe pendant 12 jours. Mais le treizi�me jour, � minuit, tous les maris cocus ex�cutent leurs femmes.\n Combien y avait il de femmes infid�les � Bagdad ?",
				"Si un homme ne connait qu'une seule femme qui trompe son mari alors il sait qu'il est lui m�me cocu (car sinon elle en connaitrait deux) et les deux hommes concern�s les auraient tu�s d�s le premier soir. Or le premier soir aucune femme n'a �t� tu�e. R�fl�chir pour le cas  de trois femmes infid�les et ainsi de suite.","14 ");
		v.add(e22);
	}
	
	//--- m�thode d'affichage ---
	public void afficher()
	{
		System.out.println(toString());
	}
	public String toString()
	{
		String chaine="";
		for(int i=0;i<v.size();i++)
		{
			//chaine+=v.elementAt(i).toString()+"\n\n";
		}
		
		// test
		Enigme test= random(100);
		chaine+=test.toString();
		
		return chaine;
	}
	
	//--- choix d'un enigme dans la bonne categorie ---
	public Enigme random(int i)
	{
		//--- on recupere les enigmes ---
		Vector<Enigme> rand=new Vector<Enigme>();

		if(i==100)
		{
			for(int h=0;h<v.size();h++)
			{
				if(v.elementAt(h).id>100 && v.elementAt(h).id<200)
				{
					rand.add(v.elementAt(h));
				}
			}
		}
		else if(i==200)
		{
			for(int h=0;h<v.size();h++)
			{
				if(v.elementAt(h).id>200 && v.elementAt(h).id<300)
				{
					rand.add(v.elementAt(h));
				}
			}
		}
		else if(i==300)
		{
			for(int h=0;h<v.size();h++)
			{
				if(v.elementAt(h).id>300 && v.elementAt(h).id<1000)
				{
					rand.add(v.elementAt(h));
				}
			}
		}
		else if(i==1000)
		{
			for(int h=0;h<v.size();h++)
			{
				if(v.elementAt(h).id>1000 && v.elementAt(h).id<2000)
				{
					rand.add(v.elementAt(h));
				}
			}
		}
		else if(i==2000)
		{
			for(int h=0;h<v.size();h++)
			{
				if(v.elementAt(h).id>2000 && v.elementAt(h).id<3000)
				{
					rand.add(v.elementAt(h));
				}
			}
		}
		else if(i==3000)
		{
			for(int h=0;h<v.size();h++)
			{
				if(v.elementAt(h).id>3000 && v.elementAt(h).id<10000)
				{
					rand.add(v.elementAt(h));
				}
			}
		}

		else
		{
			System.out.println("Olalallalalla");
			return null;
		}	
		
		// --- on en choisi une aleatoirement ---
		int max=rand.size();
		int numero=(int) Math.floor(Math.random()*max);
		
		return rand.elementAt(numero);
	}

	
	// renvoie la question en echange de l'id
	public String getQuestion(int id)
	{
		String chaine="";
		for(int i=0;i<v.size();i++)
		{
			if(v.elementAt(i).getId()==id)
			{
				chaine+=v.elementAt(i).getQuestion();
			}
		}
		return chaine;
	}
	// renvoie la question avec l'indice en echange de l'id
	
	public String getIndice(int id)
	{
		String chaine="";
		for(int i=0;i<v.size();i++)
		{
			if(v.elementAt(i).getId()==id)
			{
				chaine+="\nL'indice est: "+v.elementAt(i).getIndice();
			}
		}
		return chaine;
	}
	
	public String getReponse(int id)
	{
		String chaine="";
		for(int i=0;i<v.size();i++)
		{
			if(v.elementAt(i).getId()==id)
			{
				chaine+=v.elementAt(i).getReponse();
			}
		}
		return chaine;
	}
}
