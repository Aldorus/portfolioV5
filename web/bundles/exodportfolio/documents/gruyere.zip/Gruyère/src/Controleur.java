import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.io.IOException;

public class Controleur implements KeyListener
{
	VueCase v;
	Monde m;
	int controle;
	StockEnigme en;
	
	Controleur(VueCase v, Monde m)
	{
		this.v=v;
		this.m=m;
		controle=1;
		en=new StockEnigme();
	}
	
	public void keyPressed(KeyEvent e) 
	{
		int key=e.getKeyCode();
		if(controle==1)
		{
			if(key==KeyEvent.VK_LEFT)
			{
				controle=0;
				m.gauche();
			}
			else if(key==KeyEvent.VK_RIGHT)
			{
				controle=0;
				m.droite();
			}
			else if(key==KeyEvent.VK_DOWN)
			{
				controle=0;
				m.retourner();
			}
			else if(key==KeyEvent.VK_UP)
			{
				controle=0;
				m.haut();
			}
			
			// --- gestion des enigmes et combats
			if(controle==0)
			{
				if(m.testCombat())
				{
					m.combat();
					m.suprCombat();
					v.majIndice(m.getIndice());
				}
				else if(m.testEnigme())
				{
					Enigme enigme=en.random(m.getCase());
					v.afficherEnigme(enigme);
					m.suprEnigme();
				}
				else if(m.testSortie())
				{
					v.win();
				}
				
				v.afficherCase(m.choixCase());
				
				// --- afficher fleches ---
				if(m.aide>0)
				{
					try {
						v.afficheFleche(m.affichageFleche());
					} catch (IOException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
				}
				m.aide--;
				// test 
				//System.out.println("il reste :"+m.aide);

			     //m.afficher();
			}

		}	
	}

	public void keyReleased(KeyEvent e) {
		int key=e.getKeyCode();
		if(key==KeyEvent.VK_LEFT)
		{
			controle=1;
			
		}
		else if(key==KeyEvent.VK_RIGHT)
		{
			controle=1;

		}
		else if(key==KeyEvent.VK_DOWN)
		{
			controle=1;

		}
		else if(key==KeyEvent.VK_UP)
		{
			controle=1;

		}		
	}

	public void keyTyped(KeyEvent arg0) {
		// TODO Auto-generated method stub
		
	}
}


